var quest="";
var answers = [];
var correctAnswer = "";
var next=false;
var firstTime=true;
let answer;
var grade = 3;
var score=0;
var questionNum=0;
$(document).ready(()=>{
    $(".arrow").css({
        left:$(".arrow-man").width()
    })
    $(".arrow-man>div").css({
        height:$(".arrow-man>div").width()*1280/940,
        backgroundSize:"auto "+($(".arrow-man>div").width()*1280/940)+"px"
    });

   

    // loadJSON();
    $(".main-footer>.answers").click(e=>{
        next=false;
        answer = $(e.target).text();
        // $(".arrow-man>div").animateSprite("play","fire");
        // 
        if(firstTime){
            firstTime=false;
            $(".arrow-man>div").animateSprite({
                fps: 5,
                animations: {
                    fire: [0, 1, 2, 3],
                    initial: [0]
                },
                loop: false,
                complete: function(){
                    // alert("AA")
                    if(!next){
                        $(".arrow-man>div").animateSprite("stop",0);
                        $(".arrow").show();
                        
                        animateArrow();
                    }
                    // use complete only when you set animations with 'loop: false'
                    // alert("animation End");
                }
            });
        }
        else{
            $(".arrow-man>div").animateSprite("play","fire");
        }
    });

    $(".next").click(e=>{
        next=true;
        answers = [];
        correctAnswer="";
        quest="";
        $(".arrow-man>div").animateSprite("play","initial");
        loadJSON();
        $(".next").hide();
        $(".answers").show();
        $(".preview>div").hide();
        $(".arrow").css({
            left:$(".arrow-man").width(),
            display:"none"
        });
    });

    $(".buttons").click(e=>{
        switch($(e.target).text()){
            case "Grade 3":
                grade=3;
                break;
            case "Grade 4":
                grade=4;
                break;
            case "Grade 5":
                grade=5;
                break;
        }
        $(".overlay").hide();
        loadJSON();
    })
})


function setTargetPose(correct){
    var positions1 = ["L","R"];
    var pos1 = positions1[Math.floor(Math.random()*positions1.length)];
    var positions2 = ["T", "B"];
    var pos2 = positions2[Math.floor(Math.random()*positions2.length)];
    
    var x=0;
    var y=0;
    var startX=0;
    var endX=0;
    var startY=0;
    var endY=0;
    if(correct){
        x = $(".preview").width()/2 - 3;
        y = 3;
    }
    else{
        switch(pos2){
            case "T":
                startY = -$(".preview>div").height()+$(".preview").width()*0.15;
                endY = -$(".preview>div").height()+$(".preview").width()*0.43;
                y = startY + Math.floor(Math.random()*(endY-startY));

                break;
            case "B":
                startY = -$(".preview>div").height()+$(".preview").width()*0.62;
                endY = -$(".preview>div").height()+$(".preview").width()*0.88;
                y = startY + Math.floor(Math.random()*(endY-startY));
                break;
        }
        switch(pos1){
            case "L":
                startX = $(".preview").width()*0.1;
                endX = $(".preview").width()*0.35;
                x = startX + Math.floor(Math.random()*(endX-startX));
                break;
            case "R":
                startX = $(".preview").width()*0.6;
                endX = $(".preview").width()*0.85;
                x = startX + Math.floor(Math.random()*(endX-startX));
                break;
        }
    }
    $(".preview>div").css({
        left: x,
        top: y
    });
}

function animateArrow(){
    console.log("Answers",correctAnswer,answer);
    var correct = correctAnswer==answer;
    if(correct)score++;
    $(".arrow").animate({
        left:$(".arrow-man").width()+$(".distance").width() - $(".arrow").width()+1
    },1000,function(){
        $(".scott").animateSprite('restart')
        $(".preview>div").show();
        $(".score-text").text(score);
        setTargetPose(correct);
        $(".answers").hide()
        $(".next").css({
            display:"flex"
        });
    });
    
}

function loadJSON(){
    questionNum++;
    $(".question-text").text(questionNum);
    let json = getJSON();
    let rnd = 3+ Math.floor(Math.random()*3);
    let rnd2;
    answer = "";
    let question = json["grade"+grade];
    rnd = Math.floor(Math.random()*question["topics"].length);
    // let type = "DECIMAL_VALUE";
    let type = question["topics"][rnd];
    switch(type){
        case "MULTIPLE_SINGLE_DIGIT":
            rnd = 1 + Math.floor(Math.random()*9);
            rnd2 = 1 + Math.floor(Math.random()*4);
            quest = "What is "+rnd+" × "+rnd2+"?";
            correctAnswer = rnd*rnd2;
            answers.push(correctAnswer);
            answers.push(correctAnswer+1);
            answers.push(correctAnswer+2);
            answers.push(correctAnswer+3);
            break;
        case "DIVIDED_BY_ONE":
            rnd = 1 + Math.floor(Math.random()*99);
            rnd2 = 1;
            quest = "What is "+rnd+" ÷ "+rnd2+"?";
            correctAnswer = rnd;
            answers.push(correctAnswer);
            answers.push(correctAnswer+1);
            answers.push(correctAnswer+2);
            answers.push(correctAnswer+3);
            break;
        case "DIVIDED_BY_FIVE":
            rnd = 1 + Math.floor(Math.random()*19);
            rnd2 = 5;
            quest = "What is "+(rnd*5)+" ÷ "+rnd2+"?";
            correctAnswer = rnd;
            answers.push(correctAnswer);
            answers.push(correctAnswer+1);
            answers.push(correctAnswer+2);
            answers.push(correctAnswer+3);
            break;
        case "MULTIPLE_BY_TEN_HUNDRED_THOUSAND":
            let ar = [10,100,1000];
            rnd = Math.floor(Math.random()*3);
            rnd2 = 1 + Math.floor(Math.random()*9);
            quest = "What is "+ar[rnd]+" × "+rnd2+"?";
            correctAnswer = ar[rnd]*rnd2;
            answers.push(correctAnswer);
            answers.push(correctAnswer+1);
            answers.push(correctAnswer+2);
            answers.push(correctAnswer+3);
            break;
        case "MULTIPLE_TWO_THREE_DIGITS":
            rnd = 10 + Math.floor(Math.random()*990);
            rnd2 = 1 + Math.floor(Math.random()*9);
            quest = "What is "+rnd+" × "+rnd2+"?";
            correctAnswer = rnd*rnd2;
            answers.push(correctAnswer);
            answers.push(correctAnswer+1);
            answers.push(correctAnswer+2);
            answers.push(correctAnswer+3);
            break;
        case "DECIMAL_VALUE":
            let ar1 = ["tenths", "hundredths", "thousandths", "ten thousandths"];
            let ar2 = ["one", "two", "three", "four", "five", "six","seven", "eight","nine"];
            rnd = 1 + Math.floor(Math.random()*9);
            rnd2 = Math.floor(Math.random()*4);
            let zero = "";
            for(var i=0;i<rnd2;i++){
                zero = zero.toString()+"0".toString();
            }
            zero+=rnd.toString();
            correctAnswer = ar2[rnd-1]+" "+ar1[rnd2];
            let ar3 = ar1.filter((a)=>a!=ar1[rnd2]);
            answers.push(correctAnswer);
            answers.push(ar2[rnd-1]+" "+ar3[0]);
            answers.push(ar2[rnd-1]+" "+ar3[1]);
            answers.push(ar2[rnd-1]+" "+ar3[2]);
            quest = "What is 0."+zero+"?";
            break;
        // case "ROUNDING":
        //     break;
        case "MULTIPLY_DECIMAL":
            rnd = (Math.random()*9).toFixed(2);
            rnd2 = (Math.random()*9).toFixed(2);
            quest = "What is "+rnd+" × "+rnd2+"?";
            correctAnswer = (rnd*rnd2).toFixed(2);
            answers.push(correctAnswer);
            answers.push(correctAnswer+1);
            answers.push(correctAnswer+2);
            answers.push(correctAnswer+3);
            break;
    }
    answers = shuffle(answers);
    $(".main-header>label").text(quest);

    for(var i=0;i<answers.length;i++){
        $($(".answers")[i]).text(answers[i]);
    }
}

function shuffle(array) {
    let currentIndex = array.length,  randomIndex;
  
    // While there remain elements to shuffle.
    while (currentIndex != 0) {
  
      // Pick a remaining element.
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;
  
      // And swap it with the current element.
      [array[currentIndex], array[randomIndex]] = [
        array[randomIndex], array[currentIndex]];
    }
  
    return array;
  }