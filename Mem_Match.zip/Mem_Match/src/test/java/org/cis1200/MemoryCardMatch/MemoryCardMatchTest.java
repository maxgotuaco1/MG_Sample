package org.cis1200.MemoryCardMatch;

import org.junit.jupiter.api.*;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class MemoryCardMatchTest {

    GameBoard test = new GameBoard();

    @Test
    public void testInitialGameState() {
        // Game initializes with 16 cards in the deck,
        // and reset matches & score counters, match mode is false
        assertEquals(16, test.getActiveDeck().size());
        assertEquals(0, test.getScore());
        assertEquals(0, test.getMatches());
        //All cards are of valid suit and facename and are unmatched
        for (Card card : test.getActiveDeck()) {
            assertFalse(card.isMatched());
            assertTrue(card.isValidFaceName(card.getFaceName()));
            assertTrue(card.isValidSuit(card.getSuit()));
        }

        assertEquals(test.getFirstCard(), null);
        assertEquals(test.getSecondCard(), null);

    }
    @Test
    public void testCardClicks() {
        StandardCard card1 = new StandardCard("Hearts", "Ace", test);
        StandardCard card2 = new StandardCard("Hearts", "Ace", test);

        ArrayList<Card> deck = test.getActiveDeck();
        deck.add(card1);
        deck.add(card2);
        test.setActiveDeck(deck);

        test.handleCardClick(card1);
        //Card 1 & 2 flipped over and stored as 1st card when clicked
        assertEquals(test.getFirstCard(),card1);

        test.handleCardClick(card2);
        assertEquals(test.getFirstCard(),card1);
        assertEquals(test.getSecondCard(),card2);

    }

    @Test
    public void testStandardMatch() {
        StandardCard card1 = new StandardCard("Hearts", "Ace", test);
        StandardCard card2 = new StandardCard("Hearts", "Ace", test);
        ArrayList<Card> deck = test.getActiveDeck();
        deck.add(card1);
        deck.add(card2);
        test.setActiveDeck(deck);
        test.handleCardClick(card1);
        test.handleCardClick(card2);
        //Matches incremented, matched cards removed from active deck.
        assertEquals(1, test.getMatches());
        assertEquals(16, test.getActiveDeck().size());
    }

    @Test
    public void testOnly2Cards() {
        StandardCard card1 = new StandardCard("Hearts", "Ace", test);
        StandardCard card2 = new StandardCard("Hearts", "Ace", test);
        StandardCard card3 = new StandardCard("Hearts", "Ace", test);
        ArrayList<Card> deck = test.getActiveDeck();
        deck.add(card1);
        deck.add(card2);
        test.setActiveDeck(deck);

        test.handleCardClick(card1);
        test.handleCardClick(card2);
        Card fc = test.getFirstCard();
        Card sc = test.getSecondCard();
        assertEquals(test.getFirstCard(),card1);
        assertEquals(test.getSecondCard(),card2);
        assertTrue(fc.isFaceUp());
        assertTrue(sc.isFaceUp());
        test.handleCardClick(card3);
        Card tc = test.getFirstCard();
        assertSame(tc,card3);
        assertEquals(test.getSecondCard(),null);
    }
    @Test
    public void testOnly2CardsUnmatched() {
        StandardCard card1 = new StandardCard("Hearts", "Ace", test);
        StandardCard card2 = new StandardCard("Diamonds", "Ace", test);
        StandardCard card3 = new StandardCard("Clubs", "Ace", test);
        ArrayList<Card> deck = test.getActiveDeck();
        deck.add(card1);
        deck.add(card2);
        test.setActiveDeck(deck);

        test.handleCardClick(card1);
        test.handleCardClick(card2);
        Card fc = test.getFirstCard();
        Card sc = test.getSecondCard();
        assertEquals(test.getFirstCard(),card1);
        assertEquals(test.getSecondCard(),card2);
        assertTrue(fc.isFaceUp());
        assertTrue(sc.isFaceUp());
        test.handleCardClick(card3);
        Card tc = test.getFirstCard();
        assertSame(tc,card3);
        assertEquals(test.getSecondCard(),null);

        // Unmatched cards flipped back over
        assertFalse(fc.isFaceUp());
        assertFalse(sc.isFaceUp());
    }

    @Test
    public void testNonMatchingCards() {
        StandardCard card1 = new StandardCard("Hearts", "King", test);
        StandardCard card2 = new StandardCard("Hearts", "Ace", test);
        ArrayList<Card> deck = test.getActiveDeck();
        deck.add(card1);
        deck.add(card2);
        test.setActiveDeck(deck);

        test.handleCardClick(card1);
        test.handleCardClick(card2);

        assertTrue(test.getFirstCard().isFaceUp());
        assertTrue(test.getSecondCard().isFaceUp());

        // Matches not incremented, not removed from active deck.
        assertEquals(0, test.getMatches());
        assertEquals(18, test.getActiveDeck().size());

        assertTrue(test.getFirstCard().isFaceUp());
        assertTrue(test.getSecondCard().isFaceUp());
    }

    @Test
    public void testBombCardClick() {
        BombCard bombCard = new BombCard("Bomb", "Bomb", test);
        bombCard.onClick();
        assertEquals(5, test.getScore());
    }

    @Test
    public void testBombCardMatchGameOver() {

        BombCard bc1 = new BombCard("Bomb", "Bomb", test);
        BombCard bc2 = new BombCard("Bomb", "Bomb", test);
        test.handleCardClick(bc1);
        test.handleCardClick(bc2);
        assertTrue(test.isGameOver());

    }

    @Test
    public void testShuffleCard() {
        ShuffleCard shuffleCard = new ShuffleCard("Shuffle", "Shuffle", test);
        ArrayList<Card> deck = test.getActiveDeck();
        test.handleCardClick(shuffleCard);
        ArrayList<Card> shuffledDeck = test.getActiveDeck();
        assertNotEquals(deck, shuffledDeck);
    }

    @Test
    public void testShuffleCard2ndCard() {
        //ensures that when shuffle card is clicked as 2nd card,
        // the first card is flipped face down.
        Joker j = new Joker("Joker", "Joker");
        ShuffleCard shuffleCard = new ShuffleCard("Shuffle", "Shuffle", test);
        test.handleCardClick(j);
        assertTrue(j.isFaceUp());
        test.handleCardClick(shuffleCard);
        assertFalse(j.isFaceUp());
    }

    @Test
    public void testGameWon() {
        Joker j = new Joker("Joker", "Joker");
        Joker j2 = new Joker("Joker", "Joker");

        for (int i = 0;i < 5;i++) {
            test.incrementMatches();
            assertFalse(test.isGameOver());
        }
        test.incrementMatches();
        test.handleCardClick(j);
        test.handleCardClick(j2);
        assertTrue(test.isGameOver());
    }

    @Test
    public void testJoker() {
        Joker j = new Joker("Joker", "Joker");
        Joker j2 = new Joker("Joker", "Joker");
        test.handleCardClick(j);
        test.handleCardClick(j2);
        assertFalse(j.isMatched() || j2.isMatched());
    }

}
