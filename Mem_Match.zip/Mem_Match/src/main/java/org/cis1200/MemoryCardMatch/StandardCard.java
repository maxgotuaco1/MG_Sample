package org.cis1200.MemoryCardMatch;

public class StandardCard extends Card {
    private boolean matched;
    private GameBoard gameController;

    public StandardCard(String suit, String faceName, GameBoard gameController) {
        super(suit, faceName);
        this.gameController = gameController;
        this.matched = false;
    }

    @Override
    public boolean isMatched() {
        return matched;
    }

    @Override
    public void setMatched(boolean matched) {
        this.matched = matched;
    }

    @Override
    public void onClick() {

    }

    @Override
    public void onMatch() {
        gameController.incrementMatches();// Increment matches on the scoreboard
    }

}
