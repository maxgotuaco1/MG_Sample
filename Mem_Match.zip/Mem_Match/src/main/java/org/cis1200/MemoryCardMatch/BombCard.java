package org.cis1200.MemoryCardMatch;

public class BombCard extends Card {
    private boolean matched;
    private GameBoard gameController;

    public BombCard(String suit, String faceName, GameBoard gameController) {
        super(suit, faceName);
        this.gameController = gameController;
        this.matched = false;
    }

    @Override
    public boolean isMatched() {
        return matched;
    }

    @Override
    public void setMatched(boolean matched) {
        this.matched = matched;
    }

    // Method to handle clicking the BombCard
    @Override
    public void onClick() {
        gameController.incrementScore(5); // Increment score by 10 (example value)
    }

    @Override
    public void onMatch() {
        gameController.endGame();
        gameController.setWon(false);
    }

}

