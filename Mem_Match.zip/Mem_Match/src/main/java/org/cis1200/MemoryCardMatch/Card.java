package org.cis1200.MemoryCardMatch;

public abstract class Card {
    private String suit;
    private String faceName;
    //protected GameBoard gameController;
    private boolean faceUp;

    public Card(String suit, String faceName) {
        setSuit(suit);
        setFaceName(faceName);
        this.faceUp = false;
    }

    public String getSuit() {
        return suit;
    }

    public static String[] getValidSuits() {
        return new String[] {"hearts", "diamonds", "clubs", "spades"};
    }

    public void setSuit(String suit) {
        suit = suit.toLowerCase();
        if (isValidSuit(suit)) {
            this.suit = suit;
        } else {
            throw new IllegalArgumentException(suit + " is invalid, must be one of " +
                    String.join(", ", getValidSuits()));
        }
    }

    public boolean isValidSuit(String suit) {
        if (suit.equals("bomb") || suit.equals("shuffle") || suit.equals("joker")) {
            return true;
        }
        for (String validSuit : getValidSuits()) {
            if (validSuit.equals(suit)) {
                return true;
            }
        }
        return false;
    }

    public String getFaceName() {
        return faceName;
    }

    public static String[] getValidFaceNames() {
        return new String[] {"2", "3", "4", "5", "6", "7",
            "8", "9", "10", "jack", "queen", "king", "ace"};
    }

    public void setFaceName(String faceName) {
        faceName = faceName.toLowerCase();
        if (isValidFaceName(faceName)) {
            this.faceName = faceName;
        } else {
            throw new IllegalArgumentException(faceName + " is invalid, must be one of "
                    + String.join(", ", getValidFaceNames()));
        }
    }

    public boolean isValidFaceName(String faceName) {
        if (faceName.equals("bomb") || suit.equals("shuffle") || suit.equals("joker")) {
            return true;
        }
        for (String validFace : getValidFaceNames()) {
            if (validFace.equals(faceName)) {
                return true;
            }
        }
        return false;
    }

    public boolean isFaceUp() {
        return faceUp;
    }

    public void flip() {
        faceUp = !faceUp; // Toggle the state of the card
    }

    @Override
    public String toString() {
        return faceName + " of " + suit;
    }

    public abstract void onClick();

    public abstract void onMatch();

    public abstract void setMatched(boolean matched);

    public abstract boolean isMatched();
}
