package org.cis1200.MemoryCardMatch;


import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public class GameBoard {
    private final int winningMatches = 6;
    private final int bombCards = 2;
    private final int shuffleCards = 1;
    private final int jokers = 1;
    private Card[][] cardGrid;

    private Card firstCard, secondCard;

    public int getScore() {
        return score;
    }

    public int getMatches() {
        return matches;
    }


    private int score;
    private int matches;

    public void setActiveDeck(ArrayList<Card> activeDeck) {
        this.activeDeck = activeDeck;
    }

    private ArrayList<Card> activeDeck;
    public boolean isGameOver() {
        return gameOver;
    }

    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }

    private boolean gameOver;

    public boolean isWon() {
        return won;
    }

    public void setWon(boolean won) {
        this.won = won;
    }
    private boolean won;


    public ArrayList<Card> getActiveDeck() {
        return new ArrayList<>(activeDeck);
    }

    public Card[][] getCardGrid() {
        Card[][] cardGridCopy = new Card[cardGrid.length][];
        for (int i = 0; i < cardGrid.length; i++) {
            cardGridCopy[i] = new Card[cardGrid[i].length];
            for (int j = 0; j < cardGrid[i].length; j++) {
                cardGridCopy[i][j] = cardGrid[i][j];  // If Card is immutable, no need for deep copy
            }
        }
        return cardGridCopy;
    }

    public void setCardGrid(Card[][] cardGrid) {
        this.cardGrid = cardGrid;
    }


    public Card getFirstCard() {
        return firstCard;
    }

    public Card getSecondCard() {
        return secondCard;
    }


    public void setFirstCard(Card firstCard) {
        this.firstCard = firstCard;
    }

    public void setSecondCard(Card secondCard) {
        this.secondCard = secondCard;
    }

    public GameBoard() {
        initializeGame();
    }

    public void initializeGame() {
        System.out.println("InitializeGame called. Score reset to 0.");// Restart the game
        firstCard = null;
        secondCard = null;

        score = 0;
        matches = 0;
        setGameOver(false);


        int rows = 4, cols = 4;
        cardGrid = new Card[rows][cols];

        //cardsInGame = createShuffledDeck();
        createShuffledDeck();
        int index = 0;

        // Populate the card grid
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                cardGrid[i][j] = activeDeck.get(index++);
            }
        }
    }

    private void createShuffledDeck() {
        activeDeck = new ArrayList<>();

        String[] suits = Card.getValidSuits();
        String[] faces = Card.getValidFaceNames();
        HashSet<String> usedCards = new HashSet<>();

        while (activeDeck.size() < winningMatches * 2) { // 7 unique pairs of cards
            String suit = suits[(int) (Math.random() * suits.length)];
            String faceName = faces[(int) (Math.random() * faces.length)];
            String cardKey = suit + "-" + faceName; // Unique key for each card
            if (!usedCards.contains(cardKey)) {
                usedCards.add(cardKey);
                activeDeck.add(new StandardCard(suit, faceName, this));
                activeDeck.add(new StandardCard(suit, faceName, this)); // Matching pair
            }
        }
        for (int i = 0; i < bombCards; i++) {
            activeDeck.add(new BombCard("Bomb", "Bomb", this));
        }
        for (int i = 0; i < shuffleCards; i++) {
            activeDeck.add(new ShuffleCard("Shuffle", "Shuffle", this));
        }
        for (int i = 0; i < jokers; i++) {
            activeDeck.add(new Joker("Joker", "Joker"));
        }
        shuffleDeck();
    }

    public void shuffleDeck() {
        Collections.shuffle(activeDeck);
    }

    public void handleCardClick(Card card) {
        if (firstCard != null && secondCard != null) {
            if (!firstCard.isMatched()) {
                firstCard.flip();
                secondCard.flip();
            }
            firstCard = null;
            secondCard = null;
        }
        if (!gameOver) {
            if (firstCard == null) {
                // First card is clicked
                firstCard = card;
                firstCard.flip();
            } else if (secondCard == null && firstCard != card) {
                // Second card is clicked
                secondCard = card;
                secondCard.flip();
                incrementScore(1);
                checkForMatch();
            }
            System.out.println("firstCard: " + firstCard + ", secondCard: " + secondCard);
            card.onClick();
        }

    }

    private void checkForMatch() {
        System.out.println("checkForMatch called. firstCard=" + firstCard
                + ", secondCard=" + secondCard);
        // Check if the cards match
        if (firstCard.getFaceName().equals(secondCard.getFaceName())
                && firstCard.getSuit().equals(secondCard.getSuit())) {
            firstCard.setMatched(true);
            secondCard.setMatched(true);
        }
        if (firstCard.isMatched()) {
            activeDeck.remove(firstCard);
            firstCard.onMatch();
        }
        if (secondCard.isMatched()) {
            activeDeck.remove(secondCard);
            System.out.println(activeDeck.size());
            if (!firstCard.isMatched()) {
                secondCard.onMatch();
            }
        }
        if (matches == winningMatches) {
            endGame();
            setWon(true);
        }

    }

    public void endGame() {
        setGameOver(true);
    }

    public void incrementScore(int value) {
        score += value;
        System.out.println("score incremented by " + value);
    }

    public void incrementMatches() {
        matches++;
        System.out.println("matches incremented");
    }
}
