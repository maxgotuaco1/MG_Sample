package org.cis1200.MemoryCardMatch;

import javax.swing.*;
import java.awt.*;

public class RunCardMatch extends JFrame implements Runnable {
    private GameBoard gameController;
    private JButton[][] buttonGrid;
    private JPanel gamePanel;
    private JLabel matchesLabel;
    private JLabel scoreLabel;
    private JButton firstButton, secondButton;


    public JButton[][] getButtonGrid() {
        JButton[][] buttonGridCopy = new JButton[buttonGrid.length][];
        for (int i = 0; i < buttonGrid.length; i++) {
            buttonGridCopy[i] = new JButton[buttonGrid[i].length];
            for (int j = 0; j < buttonGrid[i].length; j++) {
                buttonGridCopy[i][j] = buttonGrid[i][j];
            }
        }
        return buttonGridCopy;

    }

    public JButton getFirstButton() {
        return firstButton;
    }

    public JButton getSecondButton() {
        return secondButton;
    }

    public void setButtonGrid(JButton[][] buttonGrid) {
        this.buttonGrid = buttonGrid;
    }


    public void setFirstButton(JButton firstButton) {
        this.firstButton = firstButton;
    }

    public void setSecondButton(JButton secondButton) {
        this.secondButton = secondButton;
    }

    public RunCardMatch() {
        gameController = new GameBoard();
        matchesLabel = new JLabel("Matches: 0");
        scoreLabel = new JLabel("Score: 0");
        gamePanel = new JPanel(new GridLayout(4, 4));
        buttonGrid = new JButton[4][4];
        initializeComponents();
        initializeGame();
    }

    private void initializeComponents() {
        setLayout(new BorderLayout());

        // Header Panel
        JPanel headerPanel = new JPanel(new FlowLayout());
        matchesLabel = new JLabel("Matches: 0");
        scoreLabel = new JLabel("Score: 0");
        headerPanel.add(matchesLabel);
        headerPanel.add(scoreLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Add Instructions Button
        JButton instructionsButton = new JButton("Instructions");
        instructionsButton.addActionListener(e -> showInstructions());
        headerPanel.add(instructionsButton);

        add(headerPanel, BorderLayout.NORTH);

        // Game Panel
        gamePanel = new JPanel(new GridLayout(4, 4, 10, 10)); // 4x4 grid for cards
        add(gamePanel, BorderLayout.CENTER);

        // Reset Button
        JButton resetButton = new JButton("Play Again");
        resetButton.addActionListener(e -> initializeGame());
        add(resetButton, BorderLayout.SOUTH);
    }

    private void initializeGame() {
        gameController.initializeGame();
        gamePanel.removeAll();

        Card[][] cardGrid = gameController.getCardGrid();
        for (int i = 0; i < cardGrid.length; i++) {
            for (int j = 0; j < cardGrid[i].length; j++) {
                JButton cardButton = new JButton();
                cardButton.setPreferredSize(new Dimension(100, 150));
                int row = i, col = j;
                cardButton.addActionListener(e -> handleCardClick(row,col));
                buttonGrid[i][j] = cardButton;
                gamePanel.add(cardButton);
            }
        }
        updateLabels();

        gamePanel.revalidate();
        gamePanel.repaint();
    }


    public void handleCardClick(int row, int col) {
        Card card = gameController.getCardGrid()[row][col];
        gameController.handleCardClick(card);
        updateLabels();
    }

    private void showCard(JButton button, Card card) {
        button.setText("<html>" + card.getFaceName() + "<br>" + card.getSuit() + "</html>");
        button.setEnabled(false);
    }

    private void hideCard(JButton button) {
        button.setText("");
        button.setEnabled(true);
    }

    private void updateLabels() {
        matchesLabel.setText("Matches: " + gameController.getMatches());
        scoreLabel.setText("Score: " + gameController.getScore());
        Card[][] cardGrid = gameController.getCardGrid();

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                JButton button = buttonGrid[i][j];
                Card card = cardGrid[i][j];
                if (card.isMatched()) {
                    button.setText("<html>" + card.getFaceName()
                        + "<br>" + card.getSuit() + "</html>");
                    button.setEnabled(false);
                } else if (card.isFaceUp()) {
                    button.setText("<html>" + card.getFaceName() +
                        "<br>" + card.getSuit() + "</html>");
                    button.setEnabled(true);
                } else {
                    button.setText("");
                    button.setEnabled(true);
                }
            }
        }
        if (gameController.isGameOver()) {
            if (gameController.isWon()) {
                JOptionPane.showMessageDialog(this,
                        "You matched all the cards! " +
                            "You won with a score of " + gameController.getScore());
            } else {
                JOptionPane.showMessageDialog(this,
                    "Game over! You matched Bomb Cards.");
            }
            initializeGame();
        }
    }

    @Override
    public void run() {
        setTitle("Memory Game");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }


    private void showInstructions() {
        String instructions = """
        Welcome to the Memory Matching Game!

        How to Play:
        - Click on a card to reveal it.
        - Match two cards with the same face and suit to score a match.
        - If the cards don't match, they will flip back over.
        - After each move, your score will increment by 1.
        
        Types of Cards:
        - Each game will have 12 standard cards, 2 bomb cards, 1 shuffle card, and 1 joker.
        - Standard Cards: These are the cards with a suit and face name. 
           The aim of the game is find all pairs of standard cards. 
        - Bomb Cards: Watch out for these! Clicking on one will 
          add an additional 5 points to your score. 
          Matching two bomb cards will result in a Game Over. 
        - Shuffle Cards: Once revealed, all unmatched cards
          will be shuffled and re-dealt. 
          The Shuffle Card can only be activated once. 
        - Joker: Filler card which does nothing and can't be matched.

        Goal: Match all pairs of standard cards to win.
        Try to keep your score as low as possible. Good luck!
            """;
        JOptionPane.showMessageDialog(this, instructions,
            "Instructions", JOptionPane.INFORMATION_MESSAGE);
    }
}
