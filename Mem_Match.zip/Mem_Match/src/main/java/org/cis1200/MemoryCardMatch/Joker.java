package org.cis1200.MemoryCardMatch;

public class Joker extends Card {
    public Joker(String suit, String faceName) {
        super(suit, faceName);
    }

    @Override
    public boolean isMatched() {
        return false;
    }

    @Override
    public void setMatched(boolean matched) {}

    @Override
    public void onClick() {}

    @Override
    public void onMatch() {}
}
