package org.cis1200.MemoryCardMatch;

import javax.swing.*;
import java.util.ArrayList;

public class ShuffleCard extends Card {
    private boolean matched;
    private GameBoard gameController;

    public ShuffleCard(String suit, String faceName, GameBoard gameController) {
        super(suit, faceName);
        this.gameController = gameController;
        this.matched = false;
    }

    @Override
    public void onClick() {

        setMatched(true);
        ArrayList<Card> deck = gameController.getActiveDeck();
        deck.remove(this);

        gameController.setActiveDeck(deck);
        gameController.shuffleDeck();
        int index = 0;
        Card[][] cardGrid  = gameController.getCardGrid();
        //JButton[][] buttonGrid = gameController.getButtonGrid();
        if (this == gameController.getSecondCard()) {
            gameController.getFirstCard().flip();
        }

        Card[][] newCardGrid = new Card[cardGrid.length][cardGrid[0].length];
        for (int i = 0; i < cardGrid.length; i++) {
            for (int j = 0; j < cardGrid[i].length; j++) {
                Card currentCard = cardGrid[i][j];
                if (!currentCard.isMatched()) {
                    newCardGrid[i][j] = deck.get(index++);
                } else {
                    newCardGrid[i][j] = currentCard;
                }
            }
        }

        gameController.setCardGrid(newCardGrid);

        gameController.setFirstCard(null);
        gameController.setSecondCard(null);
    }

    @Override
    public void onMatch() {}

    @Override
    public void setMatched(boolean matched) {
        this.matched = matched;
    }

    @Override
    public boolean isMatched() {
        return this.matched;
    }
}
