=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
CIS 1200 Game Project README
PennKey: 27004621
=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

===================
=: Core Concepts :=
===================

- List the four core concepts, the features they implement, and why each feature
  is an appropriate use of the concept. Incorporate the feedback you got after
  submitting your proposal.

  1. 2D Arrays: Two 2D Arrays, a Card[][] and a JButton [][], are used in this project to store a square grid of cards
   and buttons. This way,the positions of each card and its respective button are easily tracked and organized.
   The arrays are iterated through when setting the game board and when the board is shuffled.

  2. Collections: The primary use of collection in this project is with the ArrayList<Card> ActiveDeck.
  This collection stores all the cards remaining in play. I chose to use a collection for this purpose as the deck
  needs to be resized and shuffled throughout play. Collections.shuffle() and add/remove methods are used to do this.
  An ArrayList is used since the deck needs to be ordered as well as the order is related to the positions of the cards
  on the grid.

  3. Inheritance & Subtyping: Inheritance & Subtyping is used in this project with the Card class structure.
  The Card class is an abstract class with generic properties such as a suit and a facename which are private fields
  in the Card class. Then, there are abstract methods which determine each type of card's functionality within
  the game. There are four subtypes of the Card class. The most basic one is the Joker, which provides minimal
  functionality, not really doing anything when clicked or matched. Then, there is the StandardCard.
  It has no immediate functionality when clicked, however, it has a private boolean matched which can be accessed
  through setMatched() and isMatched, and increments the game's match counter when it is paired. The BombCard has
  a matched field similar to a StandardCard, but has a different function when clicked or matched. When clicked, the
  Bomb card increments the user's score by 5, and when matched with another Bomb card, it ends the game. Then, the
  Shuffle card is a card which has a special function when clicked. When clicked, the shuffle card is permanently
  turned face up and removed from the active deck, meaning it can only be activated once. Then, all unmatched cards are
  shuffled and re-dealt while matched cards maintain their state.

  4. JUnit testable components: 10 JUnit tests are provided in this project which aim to ensure that the game's
  core state is maintained throughout. The game is JUnit testable as the game model GameBoard housing the core logic is
  separate from the Runnable GUI Element RunCardMatch. Tests here are written to ensure that cards are revealed when
  clicked, only two unmatched cards are visible at a time, and each special card has the correct function.


===============================
=: File Structure Screenshot :=
===============================
- Include a screenshot of your project's file structure. This should include
  all of the files in your project, and the folders they are in. You can
  upload this screenshot in your homework submission to gradescope, named 
  "file_structure.png".

=========================
=: Your Implementation :=
=========================

- Provide an overview of each of the classes in your code, and what their
  function is in the overall game.
  Card Class:
  The Card class serves as an abstract card which holds the generic data for all cards such as suit, faceName
  and whether or not it is flipped. Then, the Card has abstract methods which determine what the card does when clicked
  or matched.

  StandardCard Class: The StandardCard class is a subclass of the Card class which is the main card in the game.
  It has a regular suit and face name and no additional functionality when clicked. When matched, the standard cards
  increment the game's match score by 1.

  BombCard Class: The BombCard class is a subclass of the Card class which serves as an obstacle. The bomb card
  increases the score by 5 when clicked, and ends the game when two are matched.

  ShuffleCard Class: The ShuffleCard is a subclass of the Card Class which re-shuffles all active cards when clicked.
  The Shuffle card doesn't match in pairs, instead it is removed from play as soon as it is clicked, meaning that it
  only activates at most once per game.

  Joker: The Joker is a filler card which can't be matched and has no additional functionality when clicked.

  GameBoard: The GameBoard houses the logic of the game, such as the initial set up of the card grid, how the game
  handles card clicks, and creating and modifying the active deck.

  RunCardMatch: The RunCardMatch class sets up the GUI of the game, including the labels, card buttons, and overall
  layout.



- Were there any significant stumbling blocks while you were implementing your
  game (related to your design, or otherwise)?
  I think the main stumbling block for me was the game logic of the special cards, especially the shuffle card.
  It was confusing for me to decide how to write its code and end up with the functionality I intended.


- Evaluate your design. Is there a good separation of functionality? How well is
  private state encapsulated? What would you refactor, if given the chance?

  I think that overall the game works well and the classes are well separated. However, if I had the chance, I would
  streamline the logic of the game. I think that some of the calculations, loops, and if statements are a bit clunky/



========================
=: External Resources :=
========================

- Cite any external resources (images, tutorials, etc.) that you may have used 
  while implementing your game.
  To start off with the fundamentals of the card-matching game and class structure, I took inspiration from
  this YouTube Video by Jaret Wright: https://www.youtube.com/watch?v=guXTwZpGVRk
